<?php

namespace App\Kernel\Middleware;

class Middleware implements MiddlewareInterface
{
    public function check(array $middlewares = []): void
    {
        // TODO: Implement check() method.
    }
}
