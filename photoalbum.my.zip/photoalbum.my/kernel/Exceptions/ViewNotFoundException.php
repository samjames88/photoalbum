<?php

namespace App\Kernel\Exceptions;

class ViewNotFoundException extends \Exception
{
}
