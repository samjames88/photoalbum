<?php
/**
 * @var \App\Kernel\View\ViewInterface $view
 * @var array<\App\Models\Movie> $movies
 */
?>

<?php $view->component('start'); ?>

<main>
    <div class="container">
        <h3 class="mt-3 text-white">Главная</h3>
        <hr>
        <div class="movies">
            <?php foreach ($movies as $movie) { ?>
                <?php $view->component('movie', ['movie' => $movie]); ?>
            <?php } ?>
        </div>





    </div>
</main>


<!-- //// MODAL //// -->

<div class="my-modal">
    <div class="close">
        <button type="button" onclick="fnClose();">X</button>
    </div>
    <div class="cont-img">
        <img src="" class="card-img-top" alt="<?php echo $movie->name() ?>">
    </div>
</div>

<script src="../../public/assets/js/modalscript.js"></script>

<?php $view->component('end'); ?>