<footer class="py-3 mt-auto">
    <ul class="nav justify-content-center border-bottom pb-3 mb-3">
        <li class="nav-item"><a href="/" class="nav-link px-2 text-white">Фото</a></li>
        <li class="nav-item"><a href="/admin/movies/add" class="nav-link px-2 text-white">Добавить</a></li>
        <li class="nav-item"><a href="/categories" class="nav-link px-2 text-white">Альбомы</a></li>
    </ul>
    <p class="text-center text-white">© 2024 Альбомы</p>
</footer>