<?php
/**
 * @var \App\Kernel\View\ViewInterface $view
 */
?>

<?php $view->component('footer'); ?>

<script src="/assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>
