
const myModal = document.querySelector('.my-modal');
const mybtnModal = document.querySelector('.btn-modal');
const myModalPic = document.querySelector('.my-modal img');
const myModalImgs = document.querySelectorAll('.movies .movies__item img');


function fnClose() {
myModal.classList.remove('_active');
}

myModalImgs.forEach((img)=>{
	img.addEventListener('click', (e)=>{
	myModalPic.src = e.currentTarget.src;
	console.log(e.currentTarget.src);
	myModal.classList.toggle('_active');
	});
// console.log(img.src);
});


const myLike = document.querySelectorAll('.movies .card-body .card-text svg');
const myLikeSpan = document.querySelectorAll('.movies .card-body .card-text span');

let count = [25,65,47,23,45,69,58,41,25,47,85,26,54,23,54,58,54,78,11,56,42,15];

for (let i = myLike.length - 1; i >= 0; i--) {
	const like = myLike[i];
	myLikeSpan[i].innerHTML = count[i];
	myLike[i].addEventListener('click',()=>{
		count[i]++;
		myLikeSpan[i].innerHTML = count[i];
	});
}



