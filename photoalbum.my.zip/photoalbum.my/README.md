### Вход в админа

admin@tut.by
12345qwert


### База данных лежит в папке database
photoalbum.sql





