<?php

return [
    'driver' => 'mysql',
    'host' => 'localhost',
    'port' => 3306,
    'database' => 'photoalbum',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
