<?php

return [
    'table' => 'users',
    'username' => 'email',
    'password' => 'password',
    'session_field' => 'user_id',
];
