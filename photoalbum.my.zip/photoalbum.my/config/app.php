<?php

return [
    'name' => 'Movie App',
    'url' => 'http://photoalbum.my',
];
